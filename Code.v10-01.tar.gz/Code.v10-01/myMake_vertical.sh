#!/bin/bash

#
# Jesse call to create geos executable
#

# Main options
# Met fields and resolution
MET=GEOS5
GRID=2x25
OMP=yes # use omp
NO_REDUCED=yes

# Extra options
# Version? compiler
# $VERSION=v10-01
COMPILER=ifort

# turn on UCX flag
#UCX=y
#CHEM=UCX

#echo "make -j4 MET=$MET GRID=$GRID OMP=$OMP UCX=$UCX CHEM=$CHEM"
#make -j4 MET=$MET GRID=$GRID OMP=$OMP UCX=$UCX CHEM=$CHEM
make -j4 MET=$MET GRID=$GRID OMP=$OMP 
