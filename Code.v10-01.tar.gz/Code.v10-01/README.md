#README -- Describes contents of GEOS-Chem repository

23 Jun 2015 --- GEOS-Chem Support Team --- geos-chem-support@as.harvard.edu

This repository contains the publicly-released GEOS-Chem version (v10-01, released on 17 Jun 2015).

Please see the following resources for more information:

1. http://manual.geos-chem.org  (Contains download instructions)
2. http://wiki.geos-chem.org/GEOS-Chem_v10-01
3. http://wiki.geos-chem.org/GEOS-Chem_v10-01_benchmark_history
4. http://wiki.geos-chem.org/HEMCO
5. http://wiki.geos-chem.org/GEOS-Chem-Unit-Tester
6. http://wiki.geos-chem.org/Creating_GEOS-Chem_run_directories
 
-- Bob Yantosca (23 Jun 2015)